BARCHID Sami

Tout a été fait et fonctionne parfaitement.

---------------------------------------------

Question 3 : "Le cas du cube paraît-il correcte ?"
--------------------------------------------------
Non, il n'est pas correcte.

Les normales du cube sont parallèles, ce qui donne un rendu non-convaincant.




Question 4 : Avec le bonhomme, cela ne fonctionne pas : quel est le problème selon vous ? (dans quel cas votre parcours est incorrect ?)
----------------------------------------------------------------------------------------------------------------------------------------
Le problème du bonhomme réside dans le fait qu'il y a, dans le modèle, des arêtes de bord (càd des arêtes qui ne sont incidente qu'à une seule face et pas deux).
Cependant notre parcours va échouer dans ces cas-là puisqu'il n'est prévu que pour les surfaces fermées.