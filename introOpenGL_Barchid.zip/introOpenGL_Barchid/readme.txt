BARCHID Sami

- Tout a été fait et fonctionne parfaitement.

- Les difficultés rencontrées sont les suivantes : 
	- Difficultés pour comprendre le fonctionnement de TRIANGLE_STRIPS
	- Difficultés pour gérer les positions des vertex de manière à afficher la bonne partie d'une texture
	
- Commentaires éventuels 
	- Sujet bien décrit qui teste et montre bien les connaissances à apprendre
	- Peut-être un peu plus de précision dans les questions pour la fin du TP